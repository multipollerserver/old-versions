<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2012 Andre Leinhos                                        |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by Andre Leinhos. See    |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
*/

include_once("functions.php");
include_once("update/index.php");

#include("../include/global.php");

function plugin_multipollerserver_check_config () {
$config["cacti_server_os"] = (strstr(PHP_OS, "WIN")) ? "win32" : "unix";
if ($config["cacti_server_os"] == "unix") {
//called after install
//if return true, plugin will be installed but disabled
//if return false, plugin will be waiting configuration
  return true;
  }else{ 
	cacti_log("ERROR: The Plugin Multi-Pollerserver is only for UNIX. ".$config["cacti_server_os"]."", FALSE, "POLLER");
}// is unix
}

function plugin_multipollerserver_version () {
	return array(
			'name' 	=> 'multipollerserver',
			'version'  => '0.2.2a',
			'longname' => 'Multi-Pollerserver (Cluster)',
			'author'   => 'Andre Leinhos',
			'homepage' => 'http://www.cacti-multipollerserver.de',
			'email'    => 'info@www.cacti-multipollerserver.de',
			'url'      => 'http://www.cacti-multipollerserver.de'
		);
}
#function multipollerserver_config_arrays () {
function plugin_multipollerserver_config_arrays () {
	global $tree_item_types, $tree_item_handlers, $menu;


	$wm_menu = array(
		'plugins/multipollerserver/multipollerserver.php' => "Multi-Pollerserver"
	);
	
	$menu["Management"]['plugins/multipollerserver/multipollerserver.php'] = $wm_menu;
	
}


function plugin_multipollerserver_uninstall () {
	db_execute("DROP TABLE `poller_server`");
	db_execute(" ALTER TABLE `host` DROP `poller_id`");
	db_execute(" ALTER TABLE `host` DROP `backup_poller_id`"); #0.2.2a
	db_execute(" DELETE FROM `settings` WHERE `name` = 'fallback_poller_id'"); #0.2.2a
	db_execute(" UPDATE `poller_item` SET `poller_id` = 0"); #0.2.2a
	api_plugin_remove_realms ('multipollerserver');
	
	# find cacti version
	$cacti_version = db_fetch_cell("select cacti from version");
	/* Copy org_files for Backup */
	$cp_error = 0;	
	if (!copy("plugins/multipollerserver/org_files/".$cacti_version."_poller.php.orig", "poller.php")) {
		$cp_error = 1;
		}if (!copy("plugins/multipollerserver/org_files/".$cacti_version."_lib_poller.php.orig", "lib/poller.php")) {
			$cp_error = 1;
		}if (!copy("plugins/multipollerserver/org_files/".$cacti_version."_lib_api_poller.php.orig", "lib/api_poller.php")) {
			$cp_error = 1;
		}
	
	#unlink("plugins/multipollerserver/org_files/poller.php.orig");
	#unlink("plugins/multipollerserver/org_files/lib_poller.php.orig");
	#unlink("plugins/multipollerserver/org_files/lib_api_poller.php.orig");
	uninstalllog($cp_error);
	
}



#function plugin_init_multipollerserver() {
function plugin_multipollerserver_install () {
	global $plugin_hooks, $error;
				$submit_values = array();


		api_plugin_register_realm('multipollerserver', 'multipollerserver.php', 'Plugin -> Multipollerserver: Configure', 1);
		
		api_plugin_register_hook ('multipollerserver', 'config_arrays', 'plugin_multipollerserver_config_arrays', 'setup.php');
		api_plugin_register_hook ('multipollerserver', 'config_form', 'multipollerserver_include_multipollerserver', 'setup.php');
		api_plugin_register_hook ('multipollerserver', 'api_device_save', 'multipollerserver_api_device_save', 'setup.php');
		api_plugin_enable ('multipollerserver');
		api_plugin_hook ('multipollerserver');
				
  #comming soon
	#$plugin_hooks['config_settings']['multipollerserver'] = 'multipollerserver_config_settings';	
	$plugin_hooks['config_arrays']['multipollerserver'] = 'plugin_multipollerserver_config_arrays';

	$fail_text = "<span style='color: red; font-weight: bold; font-size: 12px;'>[Fail]</span>&nbsp;";
	$success_text = "<span style='color: green; font-weight: bold; font-size: 12px;'>[Success]</span>&nbsp;";
	
	if ((multipollerserver_database_exist ("poller_server") == false) AND (api_plugin_is_enabled ('multipollerserver') == TRUE)) { // wird ausgef�hrt wenn die Tabelle noch nicht existiert.
	include("./lib/ping.php");
			?>
			<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
			<html>
			<head>
				<title>cacti</title>
				<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
				<style>
				<!--
					BODY,TABLE,TR,TD
					{
						font-size: 10pt;
						font-family: Verdana, Arial, sans-serif;
					}
					.code
					{
						font-family: Courier New, Courier;
					}
					.header-text
					{
						color: white;
						font-weight: bold;
					}
				-->
				</style>
			</head>
			<body>

			<form method="post" action="" target="_SELF">

			<table width="500" align="center" cellpadding="1" cellspacing="0" border="0" bgcolor="#104075">
				<tr bgcolor="#FFFFFF" style="height:10px;">
					<td>&nbsp;</td>
				</tr>
				<tr>
					<td width="100%">
						<table cellpadding="3" cellspacing="0" border="0" bgcolor="#E6E6E6" width="100%">
							<tr>
								<td bgcolor="#104075" class="header-text">Multipollerserver Installation Guide</td>
							</tr>
							<tr>
							<td width="100%" style="font-size: 12px;">

							<?php
							# Parameter $_POST["host_value"] wird ausgewertet
							if (isset($_POST["host_value"])) {
							
							if (is_ip($_POST["host_value"]) == TRUE){  // ip wird ausgewertet
								$pollerserver["name"] = gethostbyaddr($_POST["host_value"]);
								
								if (is_ip($pollerserver["name"]) == TRUE){
										$message_text_ip = "IP does not match with DNS request!";
										$pollerserver["name"] = "";
										$error = 1;
									}							
								else {
									$pollerserver["hostname"] = $_POST["host_value"];
									$pollerserver["name"] = split_on_dot($pollerserver["name"]);
									#$error = 0;
									}
								} //
							else { // Name wird ausgewertet
								$pollerserver["hostname"] =gethostbyname($_POST["host_value"]);
								if (is_ip($pollerserver["hostname"]) == TRUE){
									$pollerserver["name"] = split_on_dot($_POST["host_value"]);
									#$error = 0;
									}
								else {
									$message_text_name = "Name does not match with DNS request!";
									$pollerserver["hostname"] = "";
									$error = 1;
								}
							} // Ende Auswertung
							
						
								$pollerserver["availability_method"] = AVAIL_PING;
								$pollerserver["ping_port"] = 33439;
								$pollerserver["ping_timeout"] = 500;
								$pollerserver["ping_method"] = 1;
								$pollerserver["ping_retries"] = 2;
						
						 if ($pollerserver["availability_method"] == AVAIL_PING)  {
								$ping = new Net_Ping;
								$ping->host = $pollerserver;
								$ping->port = $pollerserver["ping_port"];
								
								if ($ping->ping($pollerserver["availability_method"], $pollerserver["ping_method"],
										$pollerserver["ping_timeout"], $pollerserver["ping_retries"])) {
				          	$pollerserver_down = false;
										$color     = "#000000";
									}else{
										$pollerserver_down = true;
										$color     = "#ff0000";
									}
    				   } 
					} // isset($_POST["host_value"])


							if (isset($_POST['Submit_Next']) == FALSE) {  ?>
								<p>
									IP address or hostname of masterserver:	<br> <input type="text"  size="30" name="host_value" value="<?	print ($_POST['pollerserver["hostname"]']); ?>">
								</p>
						<?php } ?>
						<?php 
						
								if(isset($_POST['Submit_Next'])) { ?>
								<p>
									<b> Hostname of masterserver:</b>		
									<p class="code"><? 
										if (($pollerserver["hostname"] <> "") AND ($pollerserver["name"] <> "")) { echo $success_text;}
										else {echo $fail_text;}
										print ($pollerserver["name"]); ?>
										<input type="hidden" name="name" value="<?php echo $pollerserver["name"]; ?>">
										<span style="font-size: 12px; font-weight: normal; color: #ff0000; font-family: monospace;">
												<?php print $message_text_name; ?>
										</span>
								</p>
								
								<p>
									<b> IP address of masterserver:</b>	<br>
										<span style="font-size: 10px; font-weight: normal; color: <?php print $color; ?>; font-family: monospace;">
										<?php print $ping->ping_response; ?>
										<?php print "Port:".$ping->port; ?>
										<?php print "Host:".$ping->host["name"]; ?>
									</span>
								</p>
								<p class="code"><?
										if (($pollerserver["name"] <> "") AND ($pollerserver["hostname"] <> "")) { echo $success_text;}
										else {echo $fail_text; $$pollerserver["hostname"] = "";}
										print ($pollerserver["hostname"]); ?>
										<input type="hidden" name="hostname" value="<?php echo $pollerserver["hostname"]; ?>">
										<span style="font-size: 12px; font-weight: normal; color: #ff0000; font-family: monospace;">
											<?php print $message_text_ip; ?>
										</span>
								</p>
								
									<b> Ping Methode:</b>
										<select name="ping_method">
											<option value="1"<?php print ($pollerserver["ping_method"] == "2") ? " selected" : "";?>>ICMP Ping</option>
											<option value="2"<?php print ($pollerserver["ping_method"] == "2") ? " selected" : "";?>>TCP Ping</option>
											<option value="3"<?php print ($pollerserver["ping_method"] == "2") ? " selected" : "";?>>UDP Ping</option>
									</select>
								</p>
								<p>
									<b> Ping Port:</b>	
											<input type="text"  size="10" name="ping_port" value="<?	print ($pollerserver["ping_port"]); ?>">
								</p>
								<p>
									<b> Ping Timeout:</b>	
											<input type="text"  size="10" name="ping_timeout" value="<?	print ($pollerserver["ping_timeout"]); ?>">
								</p>
								<p>
									<b> Ping Retries:</b>	
											<input type="text"  size="10" name="ping_retries" value="<?	print ($pollerserver["ping_retries"]); ?>">
								</p>
								<p>
									<b> aktive:</b>
										<select name="aktive">
											<option value="off"<?php print ($pollerserver["aktive"] == "off") ? " selected" : "";?>>disabled</option>
											<option value="on"<?php print ($pollerserver["aktive"] == "on") ? " selected" : "";?>>enabled</option>
									</select>
								</p>
							<?php } //isset($_POST['Submit_Next'] ?>


							<?php if(($error == "") AND ($_POST['is_filld_in'] != "true")) { ?> 
												<p align="right"><input type="image" src="install/install_next.gif" alt="Next"></p>
												<input type="hidden" name="Submit_Next" value="Submit_Next">
								<?php } ?>
								<?php if(($error == "1") AND ($_POST['is_filld_in'] == "true")) { ?> <p align="right"><input type="image" src="install/install_next.gif" alt="Next"></p> <?php } ?>
								
								<?php if(($error == "") AND ($_POST['is_filld_in'] == "true")) { ?>
										<p align="right"><input type="image" src="install/install_finish.gif" alt="Finish"></p> 
										<input type="hidden" name="Submit_Finish" value="Submit_Finish">
								<?php } ?>

								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<input type="hidden" name="is_filld_in" value="true">
			</form>
			</body>
			</html>

		<?php
	# $_POST['name']
	# $_POST['hostname']
	# $_POST['ping_method']
	# $_POST['ping port']
	# $_POST['ping_timeout']
	# $_POST['ping_retries']
	# $_POST['aktive']
		
		#print_r($_POST);
	if(isset($_POST['Submit_Finish']))
	if ($_POST['Submit_Finish'])	{
			multipollerserver_setup_database ();
			sleep(1);
			if (multipollerserver_database_exist ("poller_server") == true){
					db_execute("insert into poller_server (name, hostname, aktive, ping_method, ping_port,ping_timeout,ping_retries) values ('".$_POST['name']."','".$_POST['hostname']."','".$_POST['aktive']."','".$_POST['ping_method']."','".$_POST['ping_port']."','".$_POST['ping_timeout']."','".$_POST['ping_retries']."')");
					
					if (database_field_exist ('host','poller_id') <> true ) {
							db_execute("ALTER TABLE `host` ADD `poller_id` SMALLINT( 5 ) NOT NULL DEFAULT '0';") ;
				}	
				
				# find cacti version
				$cacti_version = db_fetch_cell("select cacti from version");
			/* install Version 0.2 */
				include ("update/0_2.php");
				upgrade_to_0_2("0.2",$cacti_version);
				
			header ("Location: index.php");
			} // multipollerserver_database_exist
		} // $_POST['Submit_Finish']
	exit;
	}// (multipollerserver_database_exist () == false)

}// plugin_init_multipollerserver()



?>
