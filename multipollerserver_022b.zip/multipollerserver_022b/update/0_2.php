<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2012 Andre Leinhos                                        |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by Andre Leinhos. See    |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
*/

function upgrade_to_0_2($new_version,$cacti_version) {

	$new_version_dell = dell_dot($new_version);
	$cacti_version_dell = dell_dot($cacti_version);

	unset($return_value);
	exec("patch -p0 -b -N < plugins/multipollerserver/patches/multipollerserver_".$new_version_dell."_".$cacti_version_dell.".patch",$return_value);
	$return_value = array_to_string($return_value,'blockquote',"<br>");
	
	if (!is_dir("plugins/multipollerserver/org_files/")){
		mkdir("plugins/multipollerserver/org_files", 0777);
	}
	/* Copy org_files for Backup */
	$cp_error = 0;	
	if (!copy("poller.php.orig", "plugins/multipollerserver/org_files/poller.php.orig")) {
		$cp_error = 1;
		}if (!copy("lib/poller.php.orig", "plugins/multipollerserver/org_files/lib_poller.php.orig")) {
			$cp_error = 1;
		}if (!copy("lib/api_poller.php.orig", "plugins/multipollerserver/org_files/lib_api_poller.php.orig")) {
			$cp_error = 1;
		}
	
	unlink("poller.php.orig");
	unlink("lib/poller.php.orig");
	unlink("lib/api_poller.php.orig");
	
	/* print logentries */
	updatelog($return_value,$cp_error,$new_version);


}

?>
