<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2012 Andre Leinhos                                        |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by Andre Leinhos. See    |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
*/

/*

Changes:
========
# Now the masterserver is ready for polling.
# Choose the devices on an listing for the pollerserver
# Show number of polling hosts
# Tidy sourcecode

Fix Bugs:
=========
# Failuremessage in pollerlog on polling (include once)
#
*/

function upgrade_to_0_2_2($new_version,$cacti_version) {
$error = '0';

/* collects logmessages*/
$return_value = array();

	$result1 = db_execute("ALTER TABLE `poller_server` ADD `hostcount` INT(5) NULL DEFAULT '0' AFTER `aktive`");
	if ($result1 == '1'){
		array_push($return_value, "Column hostcount add to table poller_server.");
	}else{
			array_push($return_value, "Column hostcount NOT add to table poller_server.");
		$error = '1';
	}

/* Update webpage in table plugin_config*/
	$plugin_id = db_fetch_cell("SELECT `id` FROM `plugin_config` WHERE `directory` = 'multipollerserver'");

	$result2 = db_execute("UPDATE `plugin_config` set `webpage` = 'http://www.cacti-multipollerserver.de'");
	if ($result2 == '1'){
		array_push($return_value, "Webpage on table plugin_config change to http://www.cacti-multipollerserver.de.");
	}else{
			array_push($return_value, "Webpage on table plugin_config NOT change to http://www.cacti-multipollerserver.de.");
		$error = '1';
	}
	
	# update the hostcount on multipollerserver overview
	update_hostcount();
	array_push($return_value, "Hostcount ist updated.");
	
	
	$return_value = array_to_string($return_value,'blockquote',"<br>");
		/* print logentries */
	updatelog($return_value,$error,$new_version);
	unset($return_value);
}

?>
