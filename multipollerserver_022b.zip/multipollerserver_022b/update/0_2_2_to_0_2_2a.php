<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2012 Andre Leinhos                                        |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by Andre Leinhos. See    |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
*/

/*

Changes:
========
# Add Fallbackpollerids
# Add Backuppollermode
# Make Backupfiles from Source
# Tidy sourcecode

Fix Bugs:
=========
# Any
#
*/

function upgrade_to_0_2_2a($new_version,$cacti_version) {
$error = '0';

/* add column fallback_poller_id*/
$return_value = array();

	$result1 = db_execute("INSERT INTO `settings`(`name`, `value`) VALUES ('fallback_poller_id','0')");
	if ($result1 == '1'){
		array_push($return_value, "Column fallback_poller_id add to table settings.");
	}else{
			array_push($return_value, "Column fallback_poller_id NOT add to table settings.");
		$error = '1';
	}
	
/* add column backup_poller_id pollerserver*/
	$result2 = db_execute("ALTER TABLE `poller_server` ADD `backup_poller_id` INT(3) NULL DEFAULT '0'");
	if ($result2 == '1'){
		array_push($return_value, "Column backup_poller_id add to table poller_server.");
	}else{
			array_push($return_value, "Column backup_poller_id NOT add to table poller_server.");
		$error = '1';
	}
	
/* add column backup_poller_id pollerserver*/
	$result3 = db_execute("ALTER TABLE `poller_server` ADD `backup_mode` INT(1) NULL DEFAULT '0'");
	if ($result3 == '1'){
		array_push($return_value, "Column backup_mode add to table poller_server.");
	}else{
			array_push($return_value, "Column backup_mode NOT add to table poller_server.");
		$error = '1';
	}

	/* add column backup_poller_id to hosts*/
	$result4 = db_execute("ALTER TABLE `host` ADD `backup_poller_id` INT(3) NULL DEFAULT '0'");
	if ($result4 == '1'){
		array_push($return_value, "Column backup_poller_id add to table host.");
	}else{
			array_push($return_value, "Column backup_poller_id NOT add to table host.");
		$error = '1';
	}
	
	# update the hostcount on multipollerserver overview
	update_hostcount();
	array_push($return_value, "Hostcount ist updated.");
	
	# patched poller.php im root
	unlink("poller.php.orig");
	$new_version_dell = dell_dot($new_version);
	$cacti_version_dell = dell_dot($cacti_version);
	
	exec("patch -p0 -b -N < plugins/multipollerserver/patches/update_multipollerserver_".$new_version_dell."_".$cacti_version_dell.".patch",$return_value);
	/* Copy org_files for Backup */
	if (!is_dir("plugins/multipollerserver/org_files/")){
		mkdir("plugins/multipollerserver/org_files", 0777);
	}
	if (!copy("poller.php.orig", "plugins/multipollerserver/org_files/".$cacti_version."_poller_0_2_2.php.orig")) {
			array_push($return_value, "poller.php.orig is NOT copy to plugins/multipollerserver/org_files/".$cacti_version."_poller_0_2_2.php.orig .");
			$error = 1;
	}else{
			array_push($return_value, "poller.php.orig is copy to plugins/multipollerserver/org_files/".$cacti_version."_poller_0_2_2.php.orig .");
			unlink("poller.php.orig");
	}
	/* rename backupfiles */
	if(!rename("plugins/multipollerserver/org_files/lib_api_poller.php.orig", "plugins/multipollerserver/org_files/".$cacti_version."_lib_api_poller.php.orig")){
			array_push($return_value, "rename /org_files/lib_api_poller.php.orig NOT to org_files/".$cacti_version."_lib_api_poller.php.orig .");
			$error = 1;
	}else{
			array_push($return_value, "rename /org_files/lib_api_poller.php.orig to org_files/".$cacti_version."_lib_api_poller.php.orig .");
	}
	if(!rename("plugins/multipollerserver/org_files/lib_poller.php.orig", "plugins/multipollerserver/org_files/".$cacti_version."_lib_poller.php.orig")){
			array_push($return_value, "rename /org_files/lib_poller.php.orig NOT to org_files/".$cacti_version."_lib_poller.php.orig .");
			$error = 1;
	}else{
			array_push($return_value, "rename /org_files/lib_poller.php.orig to org_files/".$cacti_version."_lib_poller.php.orig .");
	}
	if(!rename("plugins/multipollerserver/org_files/poller.php.orig", "plugins/multipollerserver/org_files/".$cacti_version."_poller.php.orig")){
			array_push($return_value, "rename /org_files/poller.php.orig NOT to org_files/".$cacti_version."_poller.php.orig .");
			$error = 1;
	}else{
			array_push($return_value, "rename /org_files/poller.php.orig to org_files/".$cacti_version."_poller.php.orig .");
	}	
	
	
	$return_value = array_to_string($return_value,'blockquote',"<br>");
		/* print logentries */
	updatelog($return_value,$error,$new_version);
	unset($return_value);
}

?>
