<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2012 Andre Leinhos                                        |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by Andre Leinhos. See    |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
*/

/*

Changes:
========
# Add Fallbackmode for Cactiupdate
# Fallback to single mode
# Prepaire Plugin for Cactivesion >088a
# Tidy sourcecode

Fix Bugs:
=========
# Failuremessage in pollerlog on polling (include once)
#
*/

function upgrade_to_0_2_2b($new_version,$cacti_version) {
$error = '0';

/* update table poller_item set column poller_id = 0*/
$return_value = array();

$result1 = db_execute("UPDATE `poller_item` set `poller_id` = '0'");
	if ($result1 == '1'){
		array_push($return_value, "All poller-items where set to 0.");
	}else{
			array_push($return_value, "Update the table poller_item ist broken!");
		$error = '1';
	}

/* update table settings set column fallback_poller_id to 1*/
$result2 = db_execute("UPDATE `settings` SET `value` = '1' WHERE `name` = 'fallback_poller_id'");
	if ($result2 == '1'){
		array_push($return_value, "Plugin Multipollerserver update settings for run in Fallbackmode.");
	}else{
			array_push($return_value, "Plugin Multipollerserver NOT update settings for run in Fallbackmode!");
		$error = '1';
	}
	
	$result3 = db_execute("CREATE TABLE IF NOT EXISTS `temp_multipollerserver_host` (
														  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
														  `hostname` varchar(250) NOT NULL,
														  `poller_id` smallint(5) NOT NULL,
														  `backup_poller_id` int(3) NOT NULL,
														  PRIMARY KEY (`id`)
													) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ; ");
	if ($result3 == '1'){
		array_push($return_value, "Plugin Multipollerserver backup for Fallbackmode.");
	}else{
			array_push($return_value, "Plugin Multipollerserver NOT backup for Fallbackmode!");
		$error = '1';
	}

	$sql1 = mysql_query("SELECT `hostname`,`poller_id`,`backup_poller_id` FROM `host`");
while ($erg_qry = mysql_fetch_array($sql1))
{
	$result4 = db_execute("INSERT INTO `temp_multipollerserver_host` ( `id` ,`hostname` ,`poller_id` ,`backup_poller_id`) VALUES ( NULL , '".$erg_qry['hostname']."', ".$erg_qry['poller_id'].", ".$erg_qry['backup_poller_id'].")");
	if ($result4 <> '1'){
		array_push($return_value, "Plugin Multipollerserver NOT backup for Fallbackmode!");
		$error = '1';
	}
}
	/* drop collum poller_id and backup_poller_id in table host 1*/
if (table_exists("host","poller_id") == TRUE){
	$result5 = db_execute("ALTER TABLE `host` DROP `poller_id`,  DROP `backup_poller_id`;");
		if ($result5 == '1'){
			array_push($return_value, "Plugin Multipollerserver update table hosts for run in Fallbackmode.");
		}else{
				array_push($return_value, "Plugin Multipollerserver NOT update table hosts for run in Fallbackmode!");
			$error = '1';
		}
}

if ($error == '1'){
		array_push($return_value, "Plugin Multipollerserver is NOT run in Fallbackmode!");
		}else{
		array_push($return_value, "Plugin Multipollerserver is now run in Fallbackmode.");
		}
	
	
	$result6 = db_execute("UPDATE `cacti`.`plugin_config` SET `status` = '3' WHERE `directory` = 'multipollerserver'");
	if ($result6 == '1'){
		array_push($return_value, "Plugin Multipollerserver status is chanced to Awaiting Upgrade.");
	}else{
			array_push($return_value, "Plugin Multipollerserver status is NOT chanced to Awaiting Upgrade!");
		$error = '1';
	}
		
		
		/* Copy org_files for Backup */
/*	$cp_error = 0;	
	if (!copy("plugins/multipollerserver/org_files/0.8.8a_poller.php.orig", "poller.php")) {
		$cp_error = 1;
		}if (!copy("plugins/multipollerserver/org_files/0.8.8a_lib_poller.php.orig", "lib/poller.php")) {
			$cp_error = 1;
		}if (!copy("plugins/multipollerserver/org_files/0.8.8a_lib_api_poller.php.orig", "lib/api_poller.php")) {
			$cp_error = 1;
		}
*/		
		
		
		
	$return_value = array_to_string($return_value,'blockquote',"<br>");
		/* print logentries */
	updatelog($return_value,$error,$new_version);
	unset($return_value);
}

?>
