<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2012 Andre Leinhos                                        |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by Andre Leinhos. See    |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
*/

function upgrade_to_0_2_1($new_version,$cacti_version) {

	$new_version_dell = dell_dot($new_version);
	$cacti_version_dell = dell_dot($cacti_version);
	$error = 0;
	
	unset($return_value);
	exec("patch -p0 -b -N < plugins/multipollerserver/patches/update_multipollerserver_".$new_version_dell."_".$cacti_version_dell.".patch",$return_value);
	$return_value = array_to_string($return_value,'blockquote',"<br>");
	
	/* Copy org_files for Backup */
if (!is_dir("plugins/multipollerserver/org_files/")){
		mkdir("plugins/multipollerserver/org_files", 0777);
	}
	if (!copy("poller.php.orig", "plugins/multipollerserver/org_files/poller_0_2.php.orig")) {
		$error = 1;
	}else{
			unlink("poller.php.orig");
	}
		/* print logentries */
	updatelog($return_value,$error,$new_version);
}

?>
