<?php
/*
 +-------------------------------------------------------------------------+
 | Copyright (C) 2012 Andre Leinhos                                        |
 |                                                                         |
 | This program is free software; you can redistribute it and/or           |
 | modify it under the terms of the GNU General Public License             |
 | as published by the Free Software Foundation; either version 2          |
 | of the License, or (at your option) any later version.                  |
 |                                                                         |
 | This program is distributed in the hope that it will be useful,         |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of          |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           |
 | GNU General Public License for more details.                            |
 +-------------------------------------------------------------------------+
 | Cacti: The Complete RRDTool-based Graphing Solution                     |
 +-------------------------------------------------------------------------+
 | This code is designed, written, and maintained by Andre Leinhos. See    |
 | about.php and/or the AUTHORS file for specific developer information.   |
 +-------------------------------------------------------------------------+
*/
/* Pollerserver Plugin Versions */
$multipollerserver_versions = array("0.2","0.2.1","0.2.2","0.2.2a","0.2.2b");

# find cacti version
$cacti_version = db_fetch_cell("select cacti from version");

# find pollerserver version
$old_pollerserver_version = db_fetch_cell("SELECT version FROM plugin_config WHERE directory = 'multipollerserver'", false);

/* try to find current (old) version in the array */
	$old_pollerserver_version_index = array_search($old_pollerserver_version, $multipollerserver_versions);
	if (api_plugin_is_enabled ('multipollerserver') == 1){
		for ($i=($old_pollerserver_version_index+1); $i<count($multipollerserver_versions); $i++) {
				if (($multipollerserver_versions[$i] == "0.2.1") AND ($cacti_version == "0.8.8a")){
					include ("0_2_to_0_2_1.php");
					upgrade_to_0_2_1($multipollerserver_versions[$i],$cacti_version);
				}elseif(($multipollerserver_versions[$i] == "0.2.2") AND ($cacti_version == "0.8.8a")){
					include ("0_2_1_to_0_2_2.php");
					upgrade_to_0_2_2($multipollerserver_versions[$i],$cacti_version);
				}elseif(($multipollerserver_versions[$i] == "0.2.2a") AND ($cacti_version == "0.8.8a")){
					include ("0_2_2_to_0_2_2a.php");
					upgrade_to_0_2_2a($multipollerserver_versions[$i],$cacti_version);
				}elseif(($multipollerserver_versions[$i] == "0.2.2b") AND ($cacti_version > "0.8.8a")){
					include ("0_2_2a_to_0_2_2b.php");
					upgrade_to_0_2_2b($multipollerserver_versions[$i],$cacti_version);
				}
		} // for
	} //enabled

?>

